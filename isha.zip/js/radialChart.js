// WIDTH, HEIGHT
var width = 350,
    height = 330,
    outerRadius = height / 2 - 10, //Adjust for upper height of stacked graph
    innerRadius = 100; //Adjust for height lower height of stacked graph

var formatDate = d3.time.format("%H"),
    formatDay = function(d) { return formatDate(new Date(2007, 0, 0, d)); };

var angle = d3.time.scale()
    .range([0, 2 * Math.PI]);

var radius = d3.scale.linear()
    .range([innerRadius, outerRadius]);

// var z = d3.scale.category20c();

var colors = ["#FCDF00", "#0099CC", "#B22222"];

var stack = d3.layout.stack()
    .offset("zero")
    .values(function(d) { return d.values; })
    .x(function(d) { return d.time; })
    .y(function(d) { return d.value; });

var nest = d3.nest()
    .key(function(d) { return d.key; });

var line = d3.svg.line.radial()
    .interpolate("cardinal")
    .angle(function(d) { return angle(d.time); })
    .radius(function(d) { return radius(d.y0 + d.y); });

var area = d3.svg.area.radial()
    .interpolate("cardinal")
    .angle(function(d) { return angle(d.time); })
    .innerRadius(function(d) { return radius(d.y0); })
    .outerRadius(function(d) { return radius(d.y0 + d.y); });

var svgChart = d3.select("#chart").append("svg")
    .attr("width", width)
    .attr("height", height)
  .append("g")
    .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");


var allData;

d3.csv("data/all-costs-one-week.csv",type, function(loadedRows) {

      allData = loadedRows;

      day = new Date().getDay();

      numberOfHours = 12;
      daylyData = generateDayOverview(allData, numberOfHours);

      data = daylyData.shift();
      
      var convData = convertData(data);
      loadData(convData);

});


function loadData(data)
    {

        var layers = stack(nest.entries(data));

        // Extend the domain slightly to match the range of [0, 2p].
        // angle.domain([0, d3.max(data, function(d) { return d.time + 1; })]);
        angle.domain([0, d3.max(data, function(d) { return 24; })]); // 24 hour clock (number of ticks)
        radius.domain([0, d3.max(data, function(d) { return d.y0 + d.y; })]);

        svgChart.selectAll(".layer")
            .data(layers)
          .enter().append("path")
            .attr("class", "layer")
            .attr("d", function(d) { return area(d.values); })
            .style("fill", function(d, i) { return colors[i]; });

        svgChart.selectAll(".axis")
            .data(d3.range(angle.domain()[1]))
          .enter().append("g")
            .attr("class", "axis")
            .attr("transform", function(d) { return "rotate(" + angle(d) * 180 / Math.PI + ")"; })
          .call(d3.svg.axis()
            .scale(radius.copy().range([-innerRadius, -outerRadius]))
            .orient("left"))
          .append("text")
            .attr("y", -innerRadius + 6)
            .attr("dy", ".71em")
            .attr("text-anchor", "middle")
            .text(function(d) { 
                //return ".";
                return formatDay(d); 
              });
    }


   // function convertData(rows)
   //  {
   //      var temp = [];
   //      energyPrice = 0.69; //SEK per KW
   //      coldWPrice  = 5; //SEK per m3
   //      hotWPrice   = 8; //sek per m3

   //      for (var i = 0; i < rows.length; i++) {

   //        var row = rows[i];
   //        energyVal    = row.energy * energyPrice;
   //        coldwaterVal = row.coldwater * coldWPrice;
   //        warmwaterVal = row.warmwater  * hotWPrice;

   //        var obj = {};

   //        obj = {key : "energy",    time: row.time, value: energyVal, timestamp: row.timestamp};
   //        temp.push(obj);

   //        obj = {key : "coldwater", time: row.time, value: coldwaterVal, timestamp: row.timestamp};
   //        temp.push(obj);

   //        obj = {key : "warmwater", time: row.time, value: warmwaterVal, timestamp: row.timestamp};
   //        temp.push(obj);
   //      };

   //      return temp;
   //  }

        function convertData(rows)
            {
                var temp = [];

                for (var i = 0; i < rows.length; i++) {

                  var row = rows[i];
                  electricityVal = row.electricity;
                  coldwaterVal = row.coldwater;
                  hotwaterVal = row.hotwater;

                  var obj = {};

                  obj = {key : "electricity", time: row.time, value: electricityVal, timestamp: row.timestamp};
                  temp.push(obj);

                  obj = {key : "coldwater", time: row.time, value: coldwaterVal, timestamp: row.timestamp};
                  temp.push(obj);

                  obj = {key : "hotwater", time: row.time, value: hotwaterVal, timestamp: row.timestamp};
                  temp.push(obj);
                };

                return temp;
            }



    Object.prototype.clone = function() {
      var newObj = (this instanceof Array) ? [] : {};
      for (i in this) {
        if (i == 'clone') continue;
        if (this[i] && typeof this[i] == "object") {
          newObj[i] = this[i].clone();
        } else newObj[i] = this[i]
      } return newObj;
    };

    function generateDayOverview(data,step)
    {
        var days = [];
        var day=[];
        for (var i = 0; i < data.length; i++) {

            if(((i % step == 0)&&(i!==0))||(i == data.length -1))
            {
              //day.push(allData[0]); 
              days.push(day);
              day =[];
            }

            day.push(data[i]);
            
        };



        return days;      
    }

    // function type(d) {

    //   d.timestamp = d.time;
    //   d.time      = new Date(d.time).getHours();
    //   d.energy    = +d.energy;
    //   d.coldwater = +d.coldwater;
    //   d.warmwater = +d.warmwater;
    //   return d;
    // }

      function type(d) {
        d.timestamp = d.time;
        d.day = new Date(d.time).getDay(); 
        d.time = new Date(d.time).getHours();
        d.electricity = +d.electricity;
        d.coldwater = +d.coldwater;
        d.hotwater = +d.hotwater;
        return d;
      }